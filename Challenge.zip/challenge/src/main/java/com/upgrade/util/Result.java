package com.upgrade.util;

import java.util.List;

public class Result {
	 private List<State> states;

	public List<State> getStates() {
		return states;
	}

	public void setStates(List<State> states) {
		this.states = states;
	}
	 
	 
}

