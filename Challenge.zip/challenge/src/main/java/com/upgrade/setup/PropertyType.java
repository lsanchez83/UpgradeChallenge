package com.upgrade.setup;

public enum PropertyType {	

		Id, Name, TagName, ClassName, XPath,

}
